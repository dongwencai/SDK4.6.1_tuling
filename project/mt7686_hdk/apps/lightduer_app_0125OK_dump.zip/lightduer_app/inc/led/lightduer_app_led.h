#ifndef __LIGHTDUER_APP_LED__
#define __LIGHTDUER_APP_LED__
#ifdef __cplusplus
extern "C" {

#endif

void lightduer_app_led_task(void *arg);

#ifdef __cplusplus
}
#endif

#endif

